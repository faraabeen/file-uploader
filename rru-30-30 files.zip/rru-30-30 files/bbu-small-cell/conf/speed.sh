#!/bin/bash
IF=enp4s0.3807
if [ -z "$IF" ]; then
    IF=`ls -1 /sys/class/net/ | head -1`
fi
RXPREV=-1
TXPREV=-1
echo "Listening $IF..."
sleep 30
while [ 1 == 1 ] ; do
	sum_rx=0
	sum_tx=0
	for  i in {1..180} ; do
        RX=`cat  /sys/class/net/${IF}/statistics/rx_bytes`
       	TX=`cat /sys/class/net/${IF}/statistics/tx_bytes`
       	if [ $RXPREV -ne -1 ] ; then
            let BWRX=$RX-$RXPREV
            let BWTX=$TX-$TXPREV
	    #echo "Received: $BWRX B/s    Sent: $BWTX B/s"
	    fi
     	RXPREV=$RX
      	TXPREV=$TX
	    sum_rx=$((sum_rx+BWRX))
	    sum_tx=$((sum_tx+BWTX))
        sleep  1
	done
	sum_tx=$((sum_tx/180))
	sum_rx=$((sum_rx/180))
	if [ $sum_tx -lt 2500 ] ; then
		if [ $sum_rx -lt 2500 ] ; then
            PID=$(pidof srsenb)
            echo $PID
            if [ -z "$PID" ]; then
                systemctl stop enb-faraz.service
                sleep 45
                systemctl start enb-faraz.service
                sleep 45
            else
                cpu=$(ps -p $PID -o %cpu | tail -1)
                echo $cpu
                if [ "$(echo "${cpu} > 90" | bc)" -eq 1 ]; then
                    systemctl stop enb-faraz.service
                    sleep 45
                    systemctl start enb-faraz.service
                    sleep 45
		        elif [ "$(echo "${cpu} < 20" | bc)" -eq 1 ]; then
                    systemctl stop enb-faraz.service
                    sleep 45
                    systemctl start enb-faraz.service
                    sleep 45
                else
                    echo "cpu low"
                fi
            fi
	     fi
	fi
done
