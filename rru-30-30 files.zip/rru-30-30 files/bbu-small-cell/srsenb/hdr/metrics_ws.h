/*
 *
 * This file is part of Faraz pLTE.
 *
 */

/******************************************************************************
 * File:        metrics_ws.h
 * Description: Metrics class to WS.
 *****************************************************************************/

#ifndef SRSENB_METRICS_WS_H
#define SRSENB_METRICS_WS_H

#include "srsenb/hdr/ix/ix.h"
#include "srslte/interfaces/enb_metrics_interface.h"
#include "srslte/phy/ws/json.hpp"
#include "srslte/srslte.h"
#include <pthread.h>
#include <stdint.h>
#include <string>

extern "C" {
// #include "srslte/common/common.h"
}

using json = nlohmann::json;

namespace srsenb {

class metrics_ws : public srslte::metrics_listener<enb_metrics_t>
{
public:
  metrics_ws();

  void toggle_ws(bool b,uint16_t port);
  void set_metrics(enb_metrics_t& m, const uint32_t period_usec);
  void set_handle(enb_metrics_interface* enb_);
  void stop(){};
  void ws_loop(void* m,uint16_t port);

private:
  float    dl_rate_sum = 0.0, ul_rate_sum = 0.0;
  uint16_t dl_tx     = 0;
  uint16_t ul_tx     = 0;
  uint16_t dl_errors = 0;
  uint16_t ul_errors = 0;
  uint16_t dl_pkt    = 0;
  uint16_t ul_pkt    = 0;
  uint16_t erab_num;
  uint16_t rrc_connection_setup = 0;
  uint16_t rrc_con_reest;
  uint16_t rrc_con_reject;
  uint16_t rrc_connection_release = 0;
  uint16_t rrc_con_reest_rej;
  uint16_t rrc_connection_reconfiguration = 0;
  uint16_t rrc_security_mode_command      = 0;
  uint16_t rrc_security_mode_failure      = 0;
  uint16_t rrc_ue_capability_enquiry      = 0;
  uint16_t meas_report;
  uint16_t rrc_connection_request = 0;
  uint16_t rrc_con_reest_req;
  uint16_t rrc_connection_setup_complete           = 0;
  uint16_t rrc_connection_reconfiguration_complete = 0;
  uint16_t rrc_security_mode_complete              = 0;
  uint16_t security_mode_failure;
  uint16_t rrc_ue_capability_information = 0;
  uint16_t rrc_ul_information_transfer   = 0;
  uint16_t rrc_dl_information_transfer   = 0;

  uint16_t t_dl_tx                                   = 0;
  uint16_t t_ul_tx                                   = 0;
  uint16_t t_dl_errors                               = 0;
  uint16_t t_ul_errors                               = 0;
  uint16_t t_rrc_connection_setup                    = 0;
  uint16_t t_rrc_con_reest                           = 0;
  uint16_t t_rrc_con_reject                          = 0;
  uint16_t t_rrc_connection_release                  = 0;
  uint16_t t_rrc_con_reest_rej                       = 0;
  uint16_t t_rrc_connection_reconfiguration          = 0;
  uint16_t t_rrc_security_mode_command               = 0;
  uint16_t t_rrc_security_mode_failure               = 0;
  uint16_t t_rrc_ue_capability_enquiry               = 0;
  uint16_t t_meas_report                             = 0;
  uint16_t t_rrc_connection_request                  = 0;
  uint16_t t_rrc_con_reest_req                       = 0;
  uint16_t t_rrc_connection_setup_complete           = 0;
  uint16_t t_rrc_connection_reconfiguration_complete = 0;
  uint16_t t_rrc_security_mode_complete              = 0;
  uint16_t t_rrc_ue_capability_information           = 0;
  uint16_t erab_min                                  = 0;
  uint16_t erab_max                                  = 0;
  uint16_t erab_avg                                  = 0;
  uint16_t erab_tmp                                  = 0;
  uint16_t n_avg                                     = 0;
  uint16_t nue_avg                                   = 0;
  uint16_t ue_min                                    = 0;
  uint16_t ue_max                                    = 0;
  uint16_t ue_avg                                    = 0;
  uint16_t dl_use_min                                = 0;
  uint16_t dl_use_max                                = 0;
  uint16_t dl_use_avg                                = 0;
  uint16_t ul_use_min                                = 0;
  uint16_t ul_use_max                                = 0;
  uint16_t ul_use_avg                                = 0;
  float    dl_bler                                   = 0.0;
  float    ul_bler                                   = 0.0;
  float    dl_rate                                   = 0.0;
  float    ul_rate                                   = 0.0;
  uint16_t n_bler                                    = 0;
  uint16_t ue_count_online                           = 0;
  float dl_use_online                             = 0.0F;

  uint16_t nof_dl_dci = 0;
  uint16_t nof_ul_dci = 0;
  uint16_t n_dci_metric = 0;

  // srsenb::ix_c ix_c;
  char*        msg = "";
  json         j1  = {{"message", "alarm"}, {"type", ""}, {"severity_level", 0}, {"value", 0}};
  json         j2  = {{"message", "stats"},
             {"dl_bitrate", 0},
             {"ul_bitrate", 0},
             {"dl_tx", 0},
             {"ul_tx", 0},
             {"dl_retx", 0},
             {"ul_retx", 0},
             {"dl_use_min", 0},
             {"dl_use_max", 0},
             {"dl_use_avg", 0},
             {"dl_use_online", 0},
             {"ul_use_min", 0},
             {"ul_use_max", 0},
             {"ul_use_avg", 0},
             {"ue_count_min", 0},
             {"ue_count_max", 0},
             {"ue_count_avg", 0},
             {"ue_count_online", 0},
             {"erab_count_min", 0},
             {"erab_count_max", 0},
             {"erab_count_avg", 0},
             {"rrc_connection_request", 0},
             {"rrc_connection_setup", 0},
             {"rrc_connection_setup_complete", 0},
             {"rrc_ul_information_transfer", 0},
             {"rrc_dl_information_transfer", 0},
             {"rrc_security_mode_command", 0},
             {"rrc_security_mode_complete", 0},
             {"rrc_ue_capability_enquiry", 0},
             {"rrc_ue_capability_information", 0},
             {"rrc_connection_reconfiguration", 0},
             {"rrc_connection_reconfiguration_complete", 0},
             {"rrc_connection_release", 0},
             {"message_id", "id#1"}};
  std::string  str_json_tmp;
  std::string  str_json_tmp1;

  std::string float_to_string(float f, int digits);
  std::string float_to_eng_string(float f, int digits);

  bool                   do_print;
  uint8_t                n_reports;
  enb_metrics_interface* enb;
};

} // namespace srsenb

#endif // SRSENB_METRICS_WS_H
