#ifndef COMMON_H
#define COMMON_H

#include "initialization.h"
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <sys/types.h>



typedef struct parameters
{
  int64_t tx_freq;
  float tx_gain;
  int tx_rate;
  int tx_channel_count;
  int port_count;

  int64_t rx_freq;
  float rx_gain;
  int rx_rate;
  int rx_channel_count;
} parameters;

extern parameters params;

#define revision (0x10)

#define rx_capacity (12000000)
#define timestamp_size (8)

typedef struct eCPRI_header
{
  uint8_t magic_byte[1]; // e_revision (4 bits),Reserved (3 bits),C (1 bits)
  uint8_t e_message_type[1];
  uint8_t e_payload_size[2];
} eCPRI_header;

#define IQ_header_size (4)
typedef struct msg_hdr_type0 // IQ data
{
  uint8_t PC_ID[2];  // eCPRI message header
  uint8_t SEQ_ID[2]; // eCPRI message header
} msg_hdr_type0;

// message type
// 1---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#define BIT_header_size (4)

typedef struct msg_hdr_type1 // BIT seq
{
  uint8_t PC_ID[2];
  uint8_t SEQ_ID[2];
} msg_hdr_type1;

// message type
// 2---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#define RTC_header_size (4) // 4 bytes
#define RTC_req (1)
#define RTC_resp (2)
typedef struct msg_hdr_type2 // RTC
{
  uint8_t RTC_ID[2];
  uint8_t SEQ_ID[2];
} msg_hdr_type2;

// message type
// 3---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#define generic_header_size (8)

typedef struct msg_hdr_type3 // generic data
{
  uint8_t PC_ID[4];
  uint8_t SEQ_ID[4];
} msg_hdr_type3;

/*struct pld_type3 // generic data
{
  struct msg_hdr_type3 m_hdr3;
  uint8_t *msg_userdata; // eCPRI message user data
};*/
// RMA message types and structure
// ...........................................................................................................................
#define RMA_READ (0x00) // eCPRI RMA read flag.

#define RMA_WRITE (0x10) // eCPRI RMA write flag.

#define RMA_WRITE_NR (0x20) // eCPRI RMA write flag.

#define ECPRI_RMA_MSG_READ (0x00) // ECPRI_RMA_MSG_READ eCPRI RMA read flag.

#define ECPRI_RMA_MSG_WRITE (0x10) // ECPRI_RMA_MSG_WRITE eCPRI RMA write flag.

#define ECPRI_RMA_MSG_WR_NO_RESP \
  (0x20) // ECPRI_RMA_MSG_WR_NO_RESP eCPRI RMA write with no response flag.

#define ECPRI_RMA_MSG_REQ (0x00) // ECPRI_RMA_MSG_REQ eCPRI RMA request flag.

#define ECPRI_RMA_MSG_RESP (0x01) // ECPRI_RMA_MSG_RESP eCPRI RMA response flag.

#define ECPRI_RMA_MSG_FAIL \
  (0x02) // ECPRI_RMA_MSG_FAIL eCPRI RMA request fail flag.

#define RMA_header_size (12)

struct message_type4 // RMA
{
  uint8_t RMA_ID[1];         // e_revision (4 bits),Reserved (3 bits),C (1 bits)
  uint8_t rd_wr_req_resp[1]; // 2 4bits
  uint16_t element_ID[1];
  uint8_t address[6];
  uint8_t length[2];
  uint8_t *payload;
};
//..................................................................................................................................

// RMR types and structure
// ...........................................................................................................................................
#define RMR_header_size (3)

#define ECPRI_RMR_REQ (0x01)

#define ECPRI_RMR_RESP (0x02)

typedef struct msg_hdr_type6 // RMR
{
  uint8_t reset_ID[2];
  uint8_t reset_code_op[1];
} msg_hdr_type6;
//.......................................................................................................................................................................

// OWDM types and
// structure................................................................................................................
#define OWDM_REQ (0x00)

#define OWDM_REQ_W_FU (0x01)

#define OWDM_RESP (0x02)

#define OWDM_REM_REQ (0x03)

#define OWDM_REM_REQ_W_FU (0x04)

#define OWDM_FU (0x05)

#define OWDM_header_size (20)

#define OWDM_init (0)

#define OWDM_init_flw_up (1)

#define OWDM_remote (2)

#define OWDM_remote_flw_up (3)

#define OWDM_header_size (20)

// uint8_t owdm_comp[8] = { 0, 0, 0, 0, 0, 0, 0, 0 };

typedef struct msg_hdr_type5 // owdm
{
  uint8_t m_ID[1]; // measurement_ID
  uint8_t action_type[1];
  uint8_t ts_sec[6];   // time stamp(s)
  uint8_t ts_nsec[4];  // time stamp(ns)
  uint8_t comp_val[8]; // compensation value
} msg_hdr_type5;
//...............................................................................................................................................

// Event
// indication.............................................................................................................................................................................

#define ECPRI_EI_FAULT_INDICATION 0x00

#define ECPRI_EI_FAULT_INDICATION_ACK 0x01

#define ECPRI_EI_NOTIF_INDICATION 0x02

#define ECPRI_EI_SYNC_REQUEST 0x03

#define ECPRI_EI_SYNC_ACK 0x04

#define ECPRI_EI_SYNC_END_INDICATION 0x05

#define EI_raise 0x00

#define EI_cease 0x01

#define EVENT_header_size (4 + 8 * (num_fault_notif))

// eCPRI faults and notifs:

#define General_Userplane_HW_Fault 0x000

#define General_Userplane_SW_Fault 0x001

#define Unknown_message_type_received 0x400

#define Userplane_data_buffer_underflow 0x401

#define Userplane_data_buffer_overflow 0x402

#define Userplane_data_arrived_too_early 0x403

#define Userplane_data_received_too_late 0x404

// int seq = 0;
// int fault_notif = 0;

struct message_type7_1 // Event identification
{
  uint8_t event_id[1];
  uint8_t event_type[1];
  uint8_t seq_num[1];
  uint8_t num_fault_notif[1];
};

struct message_type7_2
{
  uint16_t element_id[1];
  uint8_t raise_cease_fault_notif[1];
  uint8_t fault_notif[1];
  uint8_t add_info[4];
};

typedef enum message_type
{
  IQ_data,      // IQ Data
  BIT_seq,      // Bit Sequence
  RTC_data,     // Real-Time Control Data
  GENERIC_data, // Generic Data
  RMA,          // Remote Memory Access
  OWDM,         // One-Way Delay Measurement
  REM_RESET,    // Remote Reset
  EVENT,        // Event Indication
  /*ready,        // check the other side is ready for transformation
  strt_msging,  // start messaging
  resend_req,       // resend message
  end_msging    // end messaging*/
} msg_types;

/*return values from message types functions*/
/*struct result
{
    int retval;
    uint8_t *buffer;
    uint16_t length;
    uint8_t type;
    int buflen;
};*/

/*struct input_pack32
{
    int retval;
    uint8_t *buffer;
    uint16_t length;
    uint8_t type;
    int buflen;
};*/

/*struct ret_struct
{
    uint32_t message32[10];
    uint16_t buflen;
};*/

// Parser
// ......................................................................................................................................................
struct decapsulated_msg
{
  uint8_t p_magic_byte[1];
  uint8_t p_msg_type[1];
  uint8_t p_payload_size[2];
  uint8_t *p_pld;
};
#endif
