#ifndef ENCODER_H
#define ENCODER_H

#include <pthread.h>
#include <stdint.h>

extern clock_t start;

uint8_t *iq_data_encode(uint16_t IQ_ID, uint16_t IQ_seqID, uint8_t *message,
                        uint16_t msg_size,
                        uint8_t *encd_msg, int64_t timestamp);
uint8_t *bit_seq_encode(uint16_t BIT_ID, uint16_t BIT_seqID, uint8_t *message,
                        uint16_t msg_size,
                        uint8_t *encd_msg);
// struct input_pack32 *rtc_data(uint16_t ID, uint16_t length, uint8_t* data);

uint8_t *generic_data_encode(uint32_t Generic_ID, uint32_t Generic_seqID,
                             uint8_t *message, uint16_t msg_size,
                             uint8_t *encd_msg);

uint8_t *RTC_encode(uint8_t magic_byte, uint8_t msg_type, parameters data,
                    uint16_t data_size, uint16_t payload_size,
                    uint8_t *encd_msg, uint16_t RTC_ID, uint16_t seq_ID);

uint8_t *owdm_data_encode(uint8_t magic_byte, uint16_t dummy_bytes_size,
                          uint8_t payload_size,
                          uint8_t msr_ID, uint8_t action_type, uint64_t ts_s,
                          uint8_t *dummy_bytes);

uint8_t *Rem_Reset_encode(uint8_t magic_byte, uint8_t msg_type,
                          uint16_t payload_size, uint8_t *encd_msg,
                          uint16_t Reset_ID, uint8_t reset_codeOp);
#endif