#ifndef PARSER_H
#define PARSER_H

#include "common.h"
#include <stdint.h>
#include <pthread.h>

typedef struct parsed_header
{
    uint16_t P_pldSize;
    uint8_t P_magicByte;
    uint8_t P_msgType;
} parsed_header;
typedef struct send_recv_msg
{
    int64_t timestamp;
    uint16_t data_size;
    uint16_t PC_ID;
    uint16_t seq_ID;
    uint8_t msg_type;
    uint8_t *data;
} send_recv_msg;

typedef struct send_recv_OWDM
{
    uint16_t msg_size;
    int64_t timestamp;
    uint8_t *data;
    uint8_t msg_type;
} send_recv_OWDM;

typedef struct RMR_struct
{
    uint16_t reset_ID;
    uint8_t reset_codeop;
} RMR_struct;

typedef struct OWDM_struct
{
    uint8_t msr_ID;
    uint8_t action_type;
    uint64_t ts_send;
    uint64_t ts_recv;
    // uint32_t tns;
    uint64_t comp_val;
    uint8_t *dummy_bytes;
    uint16_t dummy_size;
    uint8_t *data;
} OWDM_struct;

// int parser_test(uint8_t *o_msg, uint8_t *p_msg);

struct parsed_header *parser(uint8_t *recv_packet);
struct send_recv_msg *IQ_data_parser(uint8_t p_magic_byte, uint16_t p_pld_size, uint8_t *recv_packet);
struct send_recv_msg *BIT_seq_parser(uint8_t p_magic_byte, uint16_t p_pld_size, uint8_t *recv_packet);
struct send_recv_msg *RTC_data_parser(uint8_t p_magic_byte, uint16_t p_pld_size, uint8_t *recv_packet);
struct send_recv_msg *GENERIC_data_parser(uint8_t p_magic_byte, uint16_t p_pld_size, uint8_t *recv_packet);
struct RMR_struct *REMreset_data_parser(uint8_t *recv_packet);
struct OWDM_struct *OWDM_parser(uint8_t *recv_packet);
#endif
