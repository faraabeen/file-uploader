/*
 * C API for the SDR board
 *
 * Copyright (C) 2014-2018 Amarisoft
 */
#ifndef SDR_LIB_H
#define SDR_LIB_H

#include <inttypes.h>

#define SDR_MAX_CHANNELS 16

typedef enum {
    SDR_SAMPLE_FMT_CF32, /* complex float32 */
} SDRSampleFormatEnum;

typedef enum {
    SDR_SYNC_NONE, /* no time synchronisation */
    SDR_SYNC_INTERNAL, /* sync on internal PPS */
    SDR_SYNC_GPS, /* use built-in GPS */
    SDR_SYNC_EXTERNAL, /* use external sync (from PPS input on board) */
#ifdef USE_CPRI
    SDR_SYNC_CPRI, /* use sync from incoming CPRI (CPRI slave mode) */
#endif
} SDRSyncSourceEnum;

typedef enum {
    SDR_CLOCK_INTERNAL, /* internal clock, using PPS to correct it */
    SDR_CLOCK_EXTERNAL, /* external clock (from clock input on board) */
} SDRClockSourceEnum;

typedef enum {
    SDR_INTERFACE_RF, /* RF interface */
#ifdef USE_CPRI
    SDR_INTERFACE_CPRI, /* CPRI interface */
#endif
} SDRInterfaceEnum;

#ifdef USE_CPRI
typedef enum {
    SDR_CPRI_SPEED_UNSUPPORTED,
    SDR_CPRI_SPEED_614_4MBPS,
    SDR_CPRI_SPEED_1228_8MBPS,
    SDR_CPRI_SPEED_2457_6MBPS,
    SDR_CPRI_SPEED_3072_0MBPS,
} SDRCPRISpeedEnum;

SDRCPRISpeedEnum cpri_speed_from_speed_mult(int speed_mult);
#endif

typedef enum {
    SDR_RX_ANTENNA_RX, /* use separate TX and RX connectors (default) */
    SDR_RX_ANTENNA_TX_RX, /* use same connector for TX and RX (TDD only) */
} SDRRXAntennaEnum;

/* hardware sample format */
typedef enum {
    SDR_SAMPLE_HW_FMT_AUTO, /* choose best format fitting the bandwidth */
    SDR_SAMPLE_HW_FMT_CI16, /* complex integer 16 bit */
    SDR_SAMPLE_HW_FMT_CF8, /* complex float 8 bit */
} SDRSampleHWFormatEnum;

typedef struct {
    SDRInterfaceEnum interface_type;

    SDRSyncSourceEnum sync_source;
    SDRClockSourceEnum clock_source;
    /* the sample rate (=sample_rate_num/sample_rate_den) for both
       transmit and receive. One by rf port */
    int64_t sample_rate_num[SDR_MAX_CHANNELS];
    int64_t sample_rate_den[SDR_MAX_CHANNELS];
    /* user sample format */
    SDRSampleFormatEnum rx_sample_fmt;
    SDRSampleFormatEnum tx_sample_fmt;
    /* hardware sample format */
    SDRSampleHWFormatEnum rx_sample_hw_fmt;
    SDRSampleHWFormatEnum tx_sample_hw_fmt;
    /* number of RX channels (=RX antennas) */
    int rx_channel_count;
    /* number of TX channels (=TX antennas) */
    int tx_channel_count;
    /* RX center frequency in Hz for each channel */
    int64_t rx_freq[SDR_MAX_CHANNELS];
    /* TX center frequency in Hz for each channel */
    int64_t tx_freq[SDR_MAX_CHANNELS];
    /* initial rx_gain for each channel, same unit as trx_set_rx_gain_func() */
    double rx_gain[SDR_MAX_CHANNELS];
    /* initial tx_gain for each channel, same unit as trx_set_tx_gain_func() */
    double tx_gain[SDR_MAX_CHANNELS];
    /* RX bandwidth, in Hz for each channel */
    int rx_bandwidth[SDR_MAX_CHANNELS];
    /* TX bandwidth, in Hz for each channel */
    int tx_bandwidth[SDR_MAX_CHANNELS];
    /* RX antenna selection */
    SDRRXAntennaEnum rx_antenna[SDR_MAX_CHANNELS];
    
    /* Number of TX/RX ports.
       A separate msdr_write() must be done for each TX port.
       Each TX port can have a different TDD configuration.
       A separate msdr_read() must be done for each RX port.
     */
    int rf_port_count;
    /* Array of rf_port_count elements containing the number of
       channels per TX/RX port. Their sum must be equal to
       tx_channel_count/rx_channel_count. */
    int tx_port_channel_count[SDR_MAX_CHANNELS];
    int rx_port_channel_count[SDR_MAX_CHANNELS];

    /* if != 0, set a custom DMA buffer configuration. Otherwise the
       default is 150 buffers per 10 ms */
    int dma_buffer_count;
    int dma_buffer_len; /* in samples */

#ifdef USE_CPRI
    /* CPRI only */
    SDRCPRISpeedEnum cpri_speed;
    char ifname[32];
    const char *config_script;
#endif

} SDRStartParams;


typedef struct {
    /* Int */
    int timeout_ms;

    /* Out */
    int8_t overflow;
} MultiSDRReadMetadata;

typedef struct {
    /* Number of times the data was sent too late by the application. */
    int64_t tx_underflow_count;
    /* Number of times the receive FIFO overflowed. */
    int64_t rx_overflow_count;
} SDRStats;

typedef struct MultiSDRState MultiSDRState;

/*
 * 'args' is a string of comma separated arguments. Available
 * arguments: 
 *
 * 'devN=value' : set the device name for the N-th board. 'dev0' is
 * assumed to have the master clock. The other boards must be
 * connected so that they are synchronized to the master.
 */
MultiSDRState *msdr_open(const char *args);
void msdr_set_default_start_params(MultiSDRState *s, SDRStartParams *p);
int msdr_start(MultiSDRState *s, const SDRStartParams *p);
int msdr_stop(MultiSDRState *s);
int msdr_set_tx_gain(MultiSDRState *s, int channel, double gain);
int msdr_set_rx_gain(MultiSDRState *s, int channel, double gain);
double msdr_get_tx_gain(MultiSDRState *s, int channel);
double msdr_get_rx_gain(MultiSDRState *s, int channel);
double msdr_get_abs_tx_power(MultiSDRState *s, int channel);
double msdr_get_abs_rx_power(MultiSDRState *s, int channel);

/* samples = NULL means to disable TX (TDD case). 'flags' is currently
   ignored. */
int msdr_write(MultiSDRState *s, int64_t timestamp, 
               const void **samples, int count, int port_index,
               int64_t *pcur_timestamp);
int msdr_read(MultiSDRState *s, int64_t *ptimestamp,
              void **samples, int count, int port_index, int timeout_ms);
void msdr_close(MultiSDRState *s);
int msdr_get_stats(MultiSDRState *s, SDRStats *m);

typedef void __attribute__ ((format (printf, 2, 3))) (*msdr_printf_cb)(void *opaque, const char *fmt, ... );
void msdr_dump_info(MultiSDRState *s, msdr_printf_cb cb, void *opaque);

#endif /* SDR_LIB_H */
