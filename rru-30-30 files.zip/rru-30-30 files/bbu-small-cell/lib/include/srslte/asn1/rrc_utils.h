/**
 * Copyright 2013-2021 Software Radio Systems Limited
 *
 * This file is part of srsRAN.
 *
 * srsRAN is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * srsRAN is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * A copy of the GNU Affero General Public License can be found in
 * the LICENSE file in the top-level directory of this distribution
 * and at http://www.gnu.org/licenses/.
 *
 */

#ifndef SRSRAN_RRC_UTILS_H
#define SRSRAN_RRC_UTILS_H

#include "srslte/interfaces/enb_interfaces.h"
// #include "srsenb/hdr/phy/phy.h"
// #include "srsran/interfaces/pdcp_interface_types.h"
// #include "srsran/interfaces/rlc_interface_types.h"
// #include "srsran/interfaces/rrc_interface_types.h"
// #include "srsran/interfaces/sched_interface.h"

/************************
 * Forward declarations
 ***********************/
namespace srslte {

template <uint32_t N, bool aligned>
class fixed_octstring;

namespace rrc {

struct plmn_id_s;
struct s_tmsi_s;
struct rlc_cfg_c;
struct pdcp_cfg_s;
struct srb_to_add_mod_s;
struct drb_to_add_mod_s;
// mac
struct sched_request_cfg_c;
struct mac_main_cfg_s;
struct rach_cfg_common_s;
struct time_align_timer_opts;
struct ant_info_ded_s;

struct phys_cfg_ded_s;
struct prach_cfg_info_s;
struct pdsch_cfg_common_s;
struct pusch_cfg_common_s;
struct pucch_cfg_common_s;
struct srs_ul_cfg_common_c;
struct ul_pwr_ctrl_common_s;
struct scell_to_add_mod_r10_s;
struct mbms_notif_cfg_r9_s;
struct mbsfn_area_info_r9_s;
struct mbsfn_sf_cfg_s;
struct mcch_msg_s;
struct sib_type13_r9_s;
// MeasConfig
struct cells_to_add_mod_s;
struct cells_to_add_mod_nr_r15_s;
struct black_cells_to_add_mod_s;
struct report_cfg_eutra_s;
struct meas_obj_to_add_mod_s;
struct report_cfg_to_add_mod_s;
struct meas_id_to_add_mod_s;
struct quant_cfg_s;

// UE Capabilities
struct ue_eutra_cap_s;

} // namespace rrc
} // namespace srslte

/************************
 *  Conversion Helpers
 ***********************/
namespace srsenb {

void set_phy_cfg_t_enable_64qam(bool enabled);

/***************************
 *  EUTRA UE Capabilities
 **************************/
phy_interface_rrc::rrc_ue_capabilities_t make_rrc_ue_capabilities(const asn1::rrc::ue_eutra_cap_s& eutra_cap_s);

void set_rrc_ue_eutra_cap_t_gen(phy_interface_rrc::rrc_ue_capabilities_t& ue_cap,
                                const asn1::rrc::ue_eutra_cap_s&          ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1250(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1250_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_11a0(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v11a0_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1180(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1180_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1170(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1170_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1130(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1130_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1090(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1090_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1060(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1060_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1020(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1020_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_940(phy_interface_rrc::rrc_ue_capabilities_t& ue_cap,
                                    const asn1::rrc::ue_eutra_cap_v940_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_920(phy_interface_rrc::rrc_ue_capabilities_t& ue_cap,
                                    const asn1::rrc::ue_eutra_cap_v920_ies_s& ue_eutra_cap);
void set_rrc_ue_eutra_cap_t_gen_1530(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1530_ies_s& ue_eutra_cap);
} // namespace srsenb

#endif // SRSRAN_RRC_UTILS_H
