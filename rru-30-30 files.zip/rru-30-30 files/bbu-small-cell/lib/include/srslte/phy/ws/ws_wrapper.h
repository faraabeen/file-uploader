/*
 *
 * This file is part of Faraz pLTE.
 *
 */

/******************************************************************************
 * File:        ws_wrapper.h
 * Description: wrapper function for WS.
 *****************************************************************************/
#ifndef WS_WRAPPER_H
#define WS_WRAPPER_H

#include <stdint.h>
#include <string.h>
#include "srslte/phy/ws/ws.h"


void metric_ws(uint16_t port);
bool check_pcap_flag(); 
bool check_teid_flag();
uint16_t check_teid();
void set_teid(uint16_t rnti);

bool check_sched_dl();
bool check_sched_ul();
bool check_grants_dl();
bool check_grants_ul();
bool check_sched_dl_timer();
bool check_sched_ul_timer();

uint16_t get_ul_nof_dci();
uint16_t get_dl_nof_dci();
void set_nof_dci(uint16_t dl, uint16_t ul);



void metric_char(char *msg);
void metric_char(char *msg);
void onclose(int fd);
void onmessage(int fd, const unsigned char *msg, uint64_t size, int type);
void onopen(int fd);
// char *msg_temp_json = " ";
#endif // WS_WRAPPER_H
