
#ifndef __DEF__H__
#define __DEF__H__


extern "C" {
#include "common.h"
#include "encoder.h"
#include "initialization.h"
#include "parser.h"

int init(uint8_t msg_type);
int socket1_init();
int socket2_init();

uint8_t *eCPRI_header_encode(uint8_t magic_b, uint8_t msg_type,
                             uint16_t msg_size, uint16_t payload_size,
                             uint8_t *encd_msg, uint8_t *message, int64_t timestamp, uint16_t PC_ID, uint16_t seq_ID);

struct parsed_header *parser(uint8_t *recv_packet);

};

#endif
