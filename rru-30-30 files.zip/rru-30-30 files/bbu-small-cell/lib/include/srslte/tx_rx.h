#include "block_queue.h"
#include "def.h"

#include <pthread.h>
#include <map>
#include <stdio.h>
#include <vector>
#include <set>
#include <mutex>
#include <iostream>
using namespace std;
namespace test
{

    class txrx_class
    {

    public:
        static txrx_class *get_instance(void);
        static std::mutex mutexx;

        static void *rx(void *object);
        // {

        //     reinterpret_cast<txrx_class *>(object)->rx();
        //     return 0;
        // }

        static void *tx(void *object);
        /*{

            reinterpret_cast<txrx_class *>(object)->tx();
            return 0;
        }*/

        static void *check_RRU(void *object);
        static void *RTC_RX(void *object);

        // struct send_recv_msg
        // {
        //     uint16_t msg_size;
        //     uint8_t *msg;
        // };
        int txrx_init(uint16_t N1_PORT, uint16_t N2_PORT, std::string N1_IP, std::string N2_IP);

        int txrx_init(uint16_t N1_PORT, uint16_t N2_PORT, uint16_t N1_RTCPORT, uint16_t N2_RTCPORT,
                      std::string N1_IP, std::string N2_IP, std::string N1_RTCIP, std::string N2_RTCIP);
        int txrx_end();
        void send_data(uint8_t *data[2], int data_size, int64_t timestamp, int send_delay);
        bool recv_data(uint8_t *data, int *len, int64_t *timestamp, int nof_bytes /*, bool reset_en*/);

        /*Remote reset send request*/
        void Remote_Reset_send_req(uint16_t reset_ID, uint8_t reset_code_op);
        bool Remote_Reset_recv_resp();

        /*Remote reset send response*/
        bool Remote_Reset_recv_req(uint16_t *reset_ID, int64_t *reset_timestamp /*, bool *reset_en*/);
        void Remote_Reset_send_resp(uint16_t reset_ID, uint8_t reset_code_op);

        void RTC_send_req(parameters params, uint16_t RTC_ID, uint16_t seq_ID);
        bool RTC_recv_resp();

        bool OWDM_recv_msg(uint8_t *msr_ID, uint64_t *ts_send, uint64_t *ts_recv);
        void OWDM_send_resp(uint8_t measurement_ID, uint64_t ts2, uint32_t tns2);

        void OWDM_send_req(uint8_t measurement_ID, uint8_t action_type, uint64_t ts_s, uint8_t *dummy_bytes);
        // bool OWDM_recv_resp(uint8_t *msr_ID, uint64_t *ts2);

        uint64_t delay_measurement(uint8_t tx_msrID);

        // void OWDM_test(uint64_t ts_s);
        // int optimized_nsample(int64_t timestamp);

        struct send_recv_msg *TX_msg = nullptr;
        struct send_recv_msg *RX_msg = nullptr;

        struct send_recv_msg TX_RTC; // = nullptr;

        struct send_recv_msg Req_RESET;  // = nullptr;
        struct send_recv_msg Resp_RESET; // = nullptr;

        struct OWDM_struct RX_OWDM;   // = nullptr;
        struct send_recv_msg TX_OWDM; // = nullptr;

        // parameters params;

        srslte::block_queue<send_recv_msg *> queue_tx;
        srslte::block_queue<send_recv_msg *> queue_RTCcheck;
        // srslte::block_queue<uint8_t *> queue_rx;
        srslte::block_queue<send_recv_msg *> queue_parser;
        srslte::block_queue<OWDM_struct> OWDM_queue_parser;

    private:
        txrx_class();
        virtual ~txrx_class();
        static txrx_class *txrx_instance;
    };
} // namespace test