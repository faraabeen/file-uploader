#ifndef INITIALIZATION_H
#define INITIALIZATION_H

#include <pthread.h>
#include <stdint.h>

// struct ret_struct init();
int init(uint8_t msg_type);

/*IQ Data variables*/
// extern msg_hdr_type0 encd_hdr0;
// extern uint16_t IQ_ID;
// extern uint16_t IQ_seqID;

/*BIT seq variables*/
extern uint16_t BIT_ID;
extern uint16_t BIT_seqID;

/*RTC Data variables*/
// extern uint16_t RTC_ID;
// extern uint16_t RTC_seqID;

/*Generic Data variables*/
extern uint32_t Generic_ID;
extern uint32_t Generic_seqID;

extern uint8_t next_type;
extern uint8_t current_type;

// extern int rtc_send;

#endif
