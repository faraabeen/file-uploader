#include <float.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "srslte/phy/ws/jsmn.h"
#include "srslte/phy/ws/ws_wrapper.h"

struct ws_events evs;
char*            msg_temp_json     = " ";
bool             ws_pcap_pcap      = false;
bool             ws_teid           = false;
uint16_t         ws_gtpu_teid      = 0;
uint16_t         nof_dci_dl_ = 0;
uint16_t         nof_dci_ul_ = 0;

bool             ws_sched_dl       = 0;
bool             ws_sched_ul       = 0;
bool             ws_grants_dl      = 0;
bool             ws_grants_ul      = 0;
bool             ws_sched_ul_timer = 0;
bool             ws_sched_dl_timer = 0;

uint16_t check_teid()
{
  return ws_gtpu_teid;
}
uint16_t get_ul_nof_dci()
{
  return nof_dci_ul_;
}
uint16_t get_dl_nof_dci()
{
  return nof_dci_dl_;
}
void set_nof_dci(uint16_t dl, uint16_t ul)
{
  nof_dci_dl_ = dl;
  nof_dci_ul_ = ul;
}

void set_teid(uint16_t rnti)
{
   ws_gtpu_teid = rnti;
}
bool check_sched_dl()
{
  return ws_sched_dl;
}
bool check_sched_ul()
{
  return ws_sched_ul;
}
bool check_grants_dl()
{
  return ws_grants_dl;
}
bool check_grants_ul()
{
  return ws_grants_ul;
}

bool check_sched_dl_timer()
{
  return ws_sched_ul_timer;
}
bool check_sched_ul_timer()
{
  return ws_sched_ul_timer;
}

bool check_teid_flag()
{
  return ws_teid;
}

static int jsoneq(const char* json, jsmntok_t* tok, const char* s)
{
  if (tok->type == JSMN_STRING && (int)strlen(s) == tok->end - tok->start &&
      strncmp(json + tok->start, s, tok->end - tok->start) == 0) {
    return 0;
  }
  return -1;
}

int json_parser(char* JSON_STRING, char* object, char* obg_message)
{
  int         i;
  int         r;
  jsmn_parser p;
  jsmntok_t   t[128]; /* We expect no more than 128 tokens */

  jsmn_init(&p);
  r = jsmn_parse(&p, JSON_STRING, strlen(JSON_STRING), t, sizeof(t) / sizeof(t[0]));
  if (r < 0) {
    printf("Failed to parse JSON: %d\n", r);
    return 1;
  }

  /* Assume the top-level element is an object */
  if (r < 1 || t[0].type != JSMN_OBJECT) {
    printf("Object expected\n");
    return 1;
  }

  /* Loop over all keys of the root object */
  for (i = 1; i < r; i++) {
    if (jsoneq(JSON_STRING, &t[i], object) == 0) {
      char* temp;
      char  obg_value[t[i + 1].end - t[i + 1].start];
      temp = JSON_STRING + t[i + 1].start;
      memcpy(obg_value, temp, t[i + 1].end - t[i + 1].start);
      memcpy(obg_message, obg_value, t[i + 1].end - t[i + 1].start);
      return 1;
    }
  }
  return 0;
}

int json_parser_len(char* JSON_STRING, char* object)
{
  int         i;
  int         r;
  jsmn_parser p;
  jsmntok_t   t[128]; /* We expect no more than 128 tokens */

  jsmn_init(&p);
  r = jsmn_parse(&p, JSON_STRING, strlen(JSON_STRING), t, sizeof(t) / sizeof(t[0]));
  if (r < 0) {
    printf("Failed to parse JSON: %d\n", r);
    return 1;
  }

  /* Assume the top-level element is an object */
  if (r < 1 || t[0].type != JSMN_OBJECT) {
    printf("Object expected\n");
    return 1;
  }

  /* Loop over all keys of the root object */
  for (i = 1; i < r; i++) {
    if (jsoneq(JSON_STRING, &t[i], object) == 0) {
      /* We may use strndup() to fetch string value */
      // printf("User: %.*s\n", t[i + 1].end - t[i + 1].start,
      //        JSON_STRING + t[i + 1].start);

      return t[i + 1].end - t[i + 1].start;
    }
  }
}

void metric_char(char* msg)
{
  msg_temp_json = msg;
}

bool check_pcap_flag()
{
  return ws_pcap_pcap;
}

void onclose(int fd)
{
  // char *cli;
  // cli = ws_getaddress(fd);
  // printf("Connection closed, client: %d | addr: %s\n", fd, cli);
  // free(cli);
}

void onmessage(int fd, const unsigned char* msg, uint64_t size, int type)
{
  // char *cli;
   //cli = ws_getaddress(fd);
   //printf("Received a message: %s (size: %" PRId64 ", type: %d), from: %s/%d\n",
   //	msg, size, type, cli, fd);
   //free(cli);
  char* object = "message";
  char  obg_message[json_parser_len(msg, object)];
  json_parser(msg, object, obg_message);
  obg_message[json_parser_len(msg, object)] = '\0';
 // printf("%s\n", obg_message);
  if (msg) {
    if (msg) {
if (strcmp(obg_message, "kpi_request") == 0) {

ws_sendframe(fd,(char*)msg_temp_json,strlen(msg_temp_json),true,type);
return;
}
      if (strcmp(obg_message, "start") == 0) {
        // ws_teid = true;

        char *object_rnti = "rnti";
        char obg_message_rnti[json_parser_len(msg, object_rnti)];
        int rnti_status = json_parser(msg, object_rnti, obg_message_rnti);
        obg_message_rnti[json_parser_len(msg, object_rnti)] = '\0';
        if (rnti_status)
        {
          printf("%s \n", obg_message_rnti);
          ws_gtpu_teid = atoi(obg_message_rnti);
        }


        char* object_dl_grants = "dl_grants";
        char  obg_message_dl_grants[json_parser_len(msg, object_dl_grants)];
        int   dl_grants_status = json_parser(msg, object_dl_grants, obg_message_dl_grants);
        obg_message_dl_grants[json_parser_len(msg, object_dl_grants)] = '\0';
        if (dl_grants_status) {
          printf("%s \n", obg_message_dl_grants);
          ws_grants_dl = atoi(obg_message_dl_grants);
        }

        char* object_ul_grants = "ul_grants";
        char  obg_message_ul_grants[json_parser_len(msg, object_ul_grants)];
        int   ul_grants_status = json_parser(msg, object_ul_grants, obg_message_ul_grants);
        obg_message_ul_grants[json_parser_len(msg, object_ul_grants)] = '\0';
        if (ul_grants_status) {
          printf("%s \n", obg_message_ul_grants);
          ws_grants_ul = atoi(obg_message_ul_grants);
        }

        char* object_sched_ul = "sched_ul";
        char  obg_message_sched_ul[json_parser_len(msg, object_sched_ul)];
        int   sched_ul_status = json_parser(msg, object_sched_ul, obg_message_sched_ul);
        obg_message_sched_ul[json_parser_len(msg, object_sched_ul)] = '\0';
        if (sched_ul_status) {
          printf("%s \n", obg_message_sched_ul);
          ws_sched_ul = atoi(obg_message_sched_ul);
        }

        char* object_sched_dl = "sched_dl";
        char  obg_message_sched_dl[json_parser_len(msg, object_sched_dl)];
        int   sched_dl_status = json_parser(msg, object_sched_dl, obg_message_sched_dl);
        obg_message_sched_dl[json_parser_len(msg, object_sched_dl)] = '\0';
        if (sched_dl_status) {
          printf("%s \n", obg_message_sched_dl);
          ws_sched_dl = atoi(obg_message_sched_dl);
        }

        char* object_sched_dl_timer = "sched_dl_timer";
        char  obg_message_sched_dl_timer[json_parser_len(msg, object_sched_dl_timer)];
        int   sched_dl_timer_status = json_parser(msg, object_sched_dl_timer, obg_message_sched_dl_timer);
        obg_message_sched_dl_timer[json_parser_len(msg, object_sched_dl_timer)] = '\0';
        if (sched_dl_timer_status) {
          printf("%s \n", obg_message_sched_dl_timer);
          ws_sched_dl_timer = atoi(obg_message_sched_dl_timer);
        }

        char* object_sched_ul_timer = "sched_ul_timer";
        char  obg_message_sched_ul_timer[json_parser_len(msg, object_sched_ul_timer)];
        int   sched_ul_timer_status = json_parser(msg, object_sched_ul_timer, obg_message_sched_ul_timer);
        obg_message_sched_ul_timer[json_parser_len(msg, object_sched_ul_timer)] = '\0';
        if (sched_ul_timer_status) {
          printf("%s \n", obg_message_sched_ul_timer);
          ws_sched_ul_timer = atoi(obg_message_sched_ul_timer);
        }
      }

      if (strcmp(obg_message, "stop") == 0) {
        // ws_teid = false;
        char* object_dl_grants = "dl_grants";
        char  obg_message_dl_grants[json_parser_len(msg, object_dl_grants)];
        int   dl_grants_status = json_parser(msg, object_dl_grants, obg_message_dl_grants);
        obg_message_dl_grants[json_parser_len(msg, object_dl_grants)] = '\0';
        if (dl_grants_status) {
          printf("%s \n", obg_message_dl_grants);
          ws_grants_dl = atoi(obg_message_dl_grants);
        }

        char* object_ul_grants = "ul_grants";
        char  obg_message_ul_grants[json_parser_len(msg, object_ul_grants)];
        int   ul_grants_status = json_parser(msg, object_ul_grants, obg_message_ul_grants);
        obg_message_ul_grants[json_parser_len(msg, object_ul_grants)] = '\0';
        if (ul_grants_status) {
          printf("%s \n", obg_message_ul_grants);
          ws_grants_ul = atoi(obg_message_ul_grants);
        }

        char* object_sched_ul = "sched_ul";
        char  obg_message_sched_ul[json_parser_len(msg, object_sched_ul)];
        int   sched_ul_status = json_parser(msg, object_sched_ul, obg_message_sched_ul);
        obg_message_sched_ul[json_parser_len(msg, object_sched_ul)] = '\0';
        if (sched_ul_status) {
          printf("%s \n", obg_message_sched_ul);
          ws_sched_ul = atoi(obg_message_sched_ul);
        }

        char* object_sched_dl = "sched_dl";
        char  obg_message_sched_dl[json_parser_len(msg, object_sched_dl)];
        int   sched_dl_status = json_parser(msg, object_sched_ul, obg_message_sched_dl);
        obg_message_sched_dl[json_parser_len(msg, object_sched_ul)] = '\0';
        if (sched_dl_status) {
          printf("%s \n", obg_message_sched_dl);
          ws_sched_dl = atoi(obg_message_sched_dl);
        }

        char* object_sched_dl_timer = "sched_dl_timer";
        char  obg_message_sched_dl_timer[json_parser_len(msg, object_sched_dl_timer)];
        int   sched_dl_timer_status = json_parser(msg, object_sched_dl_timer, obg_message_sched_dl_timer);
        obg_message_sched_dl_timer[json_parser_len(msg, object_sched_dl_timer)] = '\0';
        if (sched_dl_timer_status) {
          printf("%s \n", obg_message_sched_dl_timer);
          ws_sched_dl_timer = atoi(obg_message_sched_dl_timer);
        }

        char* object_sched_ul_timer = "sched_ul_timer";
        char  obg_message_sched_ul_timer[json_parser_len(msg, object_sched_ul_timer)];
        int   sched_ul_timer_status = json_parser(msg, object_sched_ul_timer, obg_message_sched_ul_timer);
        obg_message_sched_ul_timer[json_parser_len(msg, object_sched_ul_timer)] = '\0';
        if (sched_ul_timer_status) {
          printf("%s \n", obg_message_sched_ul_timer);
          ws_sched_ul_timer = atoi(obg_message_sched_ul_timer);
        }
      }
    }
  }
}

void onopen(int fd)
{
  // char *cli;
  // cli = ws_getaddress(fd);
  // printf("Connection opened, client: %d | addr: %s\n", fd, cli);
  // free(cli);
}

void metric_ws(uint16_t port)
{
  evs.onopen    = &onopen;
  evs.onclose   = &onclose;
  evs.onmessage = &onmessage;
  ws_socket(&evs, port);
}