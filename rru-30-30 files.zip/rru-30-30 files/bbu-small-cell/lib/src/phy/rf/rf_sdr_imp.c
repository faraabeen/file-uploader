/*
 * Copyright 2013-2019 Software Radio Systems Limited
 *
 * This file is part of srsLTE.
 *
 * srsLTE is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * srsLTE is distributed in the hope that it will be useful,times
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * A copy of the GNU Affero General Public License can be found in
 * the LICENSE file in the top-level directory of this distribution
 * and at http://www.gnu.org/licenses/.
 *
 */

#include "srslte/libsdr.h"
#include <string.h>
#include <unistd.h>

#include "rf_sdr_imp.h"
#include "srslte/srslte.h"

#define DEFAULT_ARGS "dev0=/dev/sdr0"
// #define DEFAULT_RX_FREQ ((int64_t)1715700000) // 1715700000 842000000
// #define DEFAULT_TX_FREQ ((int64_t)1810700000) //  1810700000 887000000
// #define DEFAULT_SAMPLE_RATE 5760000 * 1
#define DEFAULT_TX_GAIN 45

static const char *sync_source_str[] = {"none", "internal", "gps", "external"};
static const char *clock_source_str[] = {"internal", "external"};
int64_t timestamp = 0;
static inline void *vec_malloc(int size)
{
  void *ptr;
  if (posix_memalign(&ptr, 32, size))
    return NULL;
  return ptr;
}

typedef struct
{
  MultiSDRState *sdr_state;
  SDRStartParams sdr_params;
  pthread_t tx_thread_id;
  pthread_t rx_thread_id;
  int port_index;
  int first_timestamp;
  pthread_mutex_t mutex;
  pthread_cond_t cond;
  int sample_count;
  cf_t *rx_buf[SDR_MAX_CHANNELS];
  cf_t *rx_buf_tmp[SDR_MAX_CHANNELS];
  cf_t *tx_buf[SDR_MAX_CHANNELS];
  int buf_len;
  int tx_buf_len;
  int disc;
  int64_t tx_timestamp;
  int64_t cur_timestamp;
  int counter;
  int ret;
  uint32_t nof_rx_channels;
  int nof_tx_channels;
} RFPort;
#define CONVERT_BUFFER_SIZE (240 * 1024)
FILE *pFILE2;
srslte_rf_error_handler_t sdr_error_handler = NULL;

void rf_sdr_suppress_stdout(void *h)
{
  printf("rf_sdr_suppress \n");
}

void rf_sdr_register_error_handler(void *notused, srslte_rf_error_handler_t new_handler)
{
  printf(" rf_sdr_register_error_handler \n");
}

bool rf_sdr_rx_wait_lo_locked(void *h) {}

const unsigned int num_buffers = 256;
const unsigned int ms_buffer_size_rx = 1024;
const unsigned int buffer_size_tx = 1024;
const unsigned int num_transfers = 32;
const unsigned int timeout_ms = 4000;

char *rf_sdr_devname(void *h)
{
  return DEVNAME;
}

int rf_sdr_start_tx_stream(void *h)
{
  printf("To Start Tx Stream \n");
}

int rf_sdr_start_rx_stream(void *h, bool now) {}

int rf_sdr_stop_rx_stream(void *h) {}

void rf_sdr_flush_buffer(void *h) {}

bool rf_sdr_has_rssi(void *h) {}

float rf_sdr_get_rssi(void *h) {}

int rf_sdr_close(void *h)
{
  // rf_sdr_stop_rx_stream(h);
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  msdr_stop(handler->sdr_state);
  msdr_close(handler->sdr_state);
  free(handler);

  /* Something else to close the SDR?? */
  return SRSLTE_SUCCESS;
}

int rf_sdr_open_multi(char *args, void **h, uint32_t nof_channels)
{
  ///////////////////////The Start of Amarisoft Code////////////////////
  ///////////////////////////////////////////////////////////////////////
  //  pFILE2 = fopen("time.bin", "wb");
  int64_t tx_freq, rx_freq;
  MultiSDRState *s;

  if (h)
  {
    *h = NULL;

    RFPort *handler = (RFPort *)malloc(sizeof(RFPort));
    if (!handler)
    {
      perror("malloc");
      return -1;
    }
    bzero(handler, sizeof(RFPort));
    *h = handler;

    int option_index, c, tx_channel_count, rx_channel_count, sample_rate, rf_port_count;
    int i, p, idx, tx_bw;
    float tx_gain;
    SDRStartParams *params = &(handler->sdr_params);
    SDRSyncSourceEnum sync_source;
    SDRClockSourceEnum clock_source;
    RFPort *rf_ports;

    args = DEFAULT_ARGS;
    // printf("The Devide arg is =%s", args);
    // tx_freq = DEFAULT_TX_FREQ;
    // rx_freq = DEFAULT_RX_FREQ;
    // rx_freq=DEFAULT_TX_FREQ;
    // sample_rate = DEFAULT_SAMPLE_RATE;
    // tx_gain = DEFAULT_TX_GAIN;
    tx_channel_count = nof_channels;
    rx_channel_count = nof_channels;
    rf_port_count = 1;
    //   tx_bw = 0;
    sync_source = SDR_SYNC_INTERNAL;
    clock_source = SDR_CLOCK_INTERNAL;

    // if (tx_bw == 0)
    //  tx_bw = sample_rate;
    handler->nof_rx_channels = rx_channel_count;
    handler->nof_tx_channels = tx_channel_count;
    handler->sdr_state = msdr_open(args);
    if (!handler->sdr_state)
    {
      fprintf(stderr, "msdr_open: could not open SDR device\n");
      exit(1);
    }
    // printf("The Device Opened Correctly \n");
    msdr_set_default_start_params(s, params);

    /* Global parameters */
    params->clock_source = clock_source;
    params->sync_source = sync_source;
    params->rf_port_count = rf_port_count;

    /* Per rf port */
    rf_ports = malloc(params->rf_port_count * sizeof(*rf_ports));
    memset(rf_ports, 0, params->rf_port_count * sizeof(*rf_ports));

    // for (p = 0; p < params->rf_port_count; p++)
    {
      // RFPort *rfp = &rf_ports[p];

      handler->port_index = 0;
      // handler->sdr_state = s;

      // params->sample_rate_num[p] = sample_rate;
      // params->sample_rate_den[p] = 1;

      /* 1 hyper frame at a time */

      // handler->buf_len = sample_rate / 15000;
      // if (handler->buf_len < 100)
      //   handler->buf_len = 100;
      handler->first_timestamp = 1;
      handler->disc = 0;

      params->rx_port_channel_count[p] = rx_channel_count;
      for (i = 0; i < rx_channel_count; i++)
      {
        idx = params->rx_channel_count++;
        // params->rx_freq[idx] = rx_freq;
        // params->rx_gain[idx] = 55;
        // params->rx_bandwidth[idx] = sample_rate;
        params->rx_antenna[idx] = 0;
      }
      params->tx_port_channel_count[p] = tx_channel_count;
      for (i = 0; i < tx_channel_count; i++)
      {
        idx = params->tx_channel_count++;
        // params->tx_freq[idx] = tx_freq;
        // params->tx_gain[idx] = tx_gain;
        // params->tx_bandwidth[idx] = tx_bw;
      }
    }
    pthread_mutex_init(&handler->mutex, NULL);

    // *h = handler;
    // RFPort * handler2 =handler;
    // printf("THE FREQUCY IS =%d \n",handler2->sdr_params->rx_freq[0]);
    // msdr_close(s);

    return 0;
  }
  ////////////////////////The End of Amarisoft Code//////////////////////
}

int rf_sdr_open(char *args, void **h)
{
  printf("Trying to Open SDR \n");
}

void rf_sdr_set_master_clock_rate(void *h, double rate)
{
  printf("rf_sdr_master_clock_rate \n");
}

bool rf_sdr_is_master_clock_dynamic(void *h) {}

double rf_sdr_set_rx_srate(void *h, double rate)
{
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  params->sample_rate_num[0] = rate;
  handler->ret = rate / 1000;
  params->sample_rate_den[0] = 1;
  handler->buf_len = rate / 15000;
  if (handler->buf_len < 100)
    handler->buf_len = 100;

  for (int i = 0; i < params->rx_port_channel_count[0]; i++)
  {
    handler->rx_buf[i] = vec_malloc(rate / 1000 * sizeof(cf_t));

    params->rx_bandwidth[i] = rate;
  }
  return params->sample_rate_num[0];
}

double rf_sdr_set_tx_srate(void *h, double rate)
{
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  params->sample_rate_num[0] = rate;
  for (int i = 0; i < params->tx_port_channel_count[0]; i++)
  {
    params->tx_bandwidth[i] = rate;
    handler->tx_buf[i] = vec_malloc(rate / 1000 * sizeof(cf_t));
  }

  if (msdr_start(handler->sdr_state, params) < 0)
  {
    fprintf(stderr, "msdr_start: invalid SDR parameters\n");
    exit(1);
  }
  return params->sample_rate_num[0];
}

double rf_sdr_set_rx_gain(void *h, double gain)
{
  int ret = 0;
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  for (int i = 0; i < handler->sdr_params.rx_channel_count; i++)
  {
    params->rx_gain[i] = gain;
    ret = msdr_set_rx_gain(handler->sdr_state, i, gain);
  }
  return gain;
}

double rf_sdr_set_tx_gain(void *h, double gain)
{
  int ret = 0;
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  for (int i = 0; i < params->tx_channel_count; i++)
  {
    params->tx_gain[i] = gain;
    ret = msdr_set_tx_gain(handler->sdr_state, i, gain);
  }
  return gain;
}

double rf_sdr_get_rx_gain(void *h)
{
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  double gain;
  gain = params->rx_gain[0];
  // gain = msdr_get_rx_gain(handler->sdr_state, 0);
  return gain;
}

double rf_sdr_get_tx_gain(void *h)
{
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  double gain;
  gain = params->tx_gain[0];
  // gain = msdr_get_tx_gain(handler->sdr_state, 0);
  return gain;
}

srslte_rf_info_t *rf_sdr_get_info(void *h) {}

double rf_sdr_set_rx_freq(void *h, uint32_t ch, double freq)
{
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  for (int i = 0; i < handler->sdr_params.rx_channel_count; i++)
  {
    params->rx_freq[i] = freq;
  }
  return freq;
}

double rf_sdr_set_tx_freq(void *h, uint32_t ch, double freq)
{
  RFPort *handler = h;
  SDRStartParams *params = &(handler->sdr_params);
  for (int i = 0; i < handler->sdr_params.tx_channel_count; i++)
  {
    params->tx_freq[i] = freq;
  }
  return freq;
}

static void timestamp_to_secs(uint32_t rate, uint64_t timestamp, time_t *secs, double *frac_secs) {}

static void secs_to_timestamps(uint32_t rate, time_t secs, double frac_secs, uint64_t *timestamp) {}

void rf_sdr_get_time(void *h, time_t *secs, double *frac_secs) {}

int rf_sdr_recv_with_time_multi(void *h, void **data, uint32_t nsamples, bool blocking, time_t *secs, double *frac_secs)
{
  RFPort *rfp = h;
  int64_t rx_timestamp = 0;
  int ret;
  MultiSDRReadMetadata mdr;

  mdr.timeout_ms = 10000;
  int rx_packet = 0;
  cf_t *data_c;
  int64_t disc = 0;
  SDRStats m_stats;
  while (rx_packet < nsamples)
  {
    void *buffs_ptr[4];

    for (int i = 0; i < rfp->nof_rx_channels; i++)
    {
      cf_t *data_c = (cf_t *)data[i];
      buffs_ptr[i] = &data_c[rx_packet];
    }
    // printf("%d\n",rfp->port_index);
    ret = msdr_read(rfp->sdr_state, &rx_timestamp, (void **)buffs_ptr, rfp->buf_len, rfp->port_index, mdr.timeout_ms);

    if (ret < 0)
    {
      fprintf(stderr, "mread_read: Timed_out\n");
      exit(1);
    }

    if (rfp->cur_timestamp != rx_timestamp && !rfp->first_timestamp)
    {
      rfp->disc = rfp->cur_timestamp - rx_timestamp;
    }
    if (rfp->first_timestamp)
    {
      rfp->cur_timestamp = rx_timestamp;
      rfp->first_timestamp = 0;
    }
    rfp->cur_timestamp = rfp->cur_timestamp + ret;
    // memcpy(data_c + rx_packet, rfp->rx_buf[0], ret * sizeof(rfp->rx_buf[0]));
    rx_packet = rx_packet + ret;
  }

  if (rx_packet > 0)
  {
    pthread_mutex_lock(&rfp->mutex);
    *secs = (rx_timestamp - rfp->disc) / rfp->sdr_params.sample_rate_num[0];
    *frac_secs = ((double)((rx_timestamp - rfp->disc) % rfp->sdr_params.sample_rate_num[0])) /
                 ((double)(rfp->sdr_params.sample_rate_num[0]));
    rfp->disc = 0;
    // fwrite((cf_t*)data[0], sizeof(cf_t), nsamples, pFILE2);

    /* Wake up TX thread as new data are available */
    // pthread_cond_signal(&rfp->cond);
    pthread_mutex_unlock(&rfp->mutex);
  }
  return ret;
}

int rf_sdr_recv_with_time(void *h, void *data, uint32_t nsamples, bool blocking, time_t *secs, double *frac_secs)
{
  // printf("The Recv Function 2\n");
}

int rf_sdr_send_timed_multi(void *h,
                            void *data[4],
                            int nsamples,
                            time_t secs,
                            double frac_secs,
                            bool has_time_spec,
                            bool blocking,
                            bool is_start_of_burst,
                            bool is_end_of_burst)
{
  // printf("The Tx Function \n");

  RFPort *rfp = h;
  int ret;

  // thread_configure("TX%d", rfp->port_index);

  // while (keep_running)

  pthread_mutex_lock(&rfp->mutex);

  int idx = 0;
  int tx_packet = 0;
  rfp->tx_buf_len = nsamples;
  int64_t tmp1 = 0;
  // if (!keep_running)
  //     break;
  tmp1 = rfp->tx_timestamp;
  rfp->tx_timestamp = ((secs + frac_secs) * rfp->sdr_params.sample_rate_num[0]);
  while ((rfp->tx_timestamp - tmp1 - rfp->ret) < 0)
  {
    rfp->tx_timestamp++;
  }
  ret = rfp->ret;
  while (tx_packet < nsamples)
  {
    //  memcpy(rfp->tx_buf[0], data_c+tx_packet, ret * sizeof(rfp->tx_buf[0]));
    ret = msdr_write(rfp->sdr_state, rfp->tx_timestamp, (const void **)data, ret, 0, NULL);
    tx_packet = tx_packet + ret;
  }

  //  fwrite((cf_t*) rfp->tx_buf[0],sizeof(cf_t),rfp->tx_buf_len,pFILE2);

  pthread_mutex_unlock(&rfp->mutex);

  return tx_packet;
}

int rf_sdr_send_timed(void *h,
                      void *data,
                      int nsamples,
                      time_t secs,
                      double frac_secs,
                      bool has_time_spec,
                      bool blocking,
                      bool is_start_of_burst,
                      bool is_end_of_burst)
{
  // fprintf()
  //   printf("The Tx Function 2\n");
}