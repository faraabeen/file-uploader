/*
 * Copyright 2013-2019 Software Radio Systems Limited
 *
 * This file is part of srsLTE.
 *
 * srsLTE is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * srsLTE is distributed in the hope that it will be useful,times
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * A copy of the GNU Affero General Public License can be found in
 * the LICENSE file in the top-level directory of this distribution
 * and at http://www.gnu.org/licenses/.
 *
 */
// #include <atomic>
// #include "srslte/libsdr.h"
#include "srslte/tx_rx.h"
#include <unistd.h>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>
bool flag_not = false;
int co = 0;
int count_tti=0;
uint8_t *r_buffer[10][2] = {};

extern "C"
{

  // #include <string.h>
  // #include <unistd.h>
  // #include <stdio.h>

#include "rf_ecpri_imp.h"
}
#include "srslte/common.h"
std::vector<uint8_t **> testtt;
#include "srslte/srslte.h"
using namespace test;
srslte_rf_info_t x;
// FILE *fd;
int64_t tmp1 = 0;
int64_t tmp_time = 0;
int64_t tmp_time2 = 0;

parameters params;
int BBU_start = 1;
ecpri_args_t *ecpri_args;
// #define DEFAULT_ARGS "dev0=/dev/sdr0"

std::string time_in_HH_MM_SS_MMM222()
{
  using namespace std::chrono;

  // get current time
  auto now = system_clock::now();

  // get number of milliseconds for the current second
  // (remainder after division into seconds)
  auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
  auto us = duration_cast<microseconds>(now.time_since_epoch()) % 1000000;

  // convert to std::time_t in order to convert to std::tm (broken time)
  auto timer = system_clock::to_time_t(now);

  // convert to broken time
  std::tm bt = *std::localtime(&timer);

  std::ostringstream oss;

  oss << std::put_time(&bt, "%H:%M:%S"); // HH:MM:SS
  oss << '.' << std::setfill('0') << std::setw(3) << ms.count();
  oss << '.' << std::setfill('0') << std::setw(6) << us.count();
  // int64_t microesec = static_cast<int64_t>(us / microseconds(1));
  int64_t sec = static_cast<int64_t>(now.time_since_epoch() / nanoseconds(1));

  return oss.str();
}

std::string time_in_HH_MM_SS_MMM()
{
  using namespace std::chrono;

  // get current time
  auto now = system_clock::now();

  // get number of milliseconds for the current second
  // (remainder after division into seconds)
  auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;

  // convert to std::time_t in order to convert to std::tm (broken time)
  auto timer = system_clock::to_time_t(now);

  // convert to broken time
  std::tm bt = *std::localtime(&timer);

  std::ostringstream oss;

  oss << std::put_time(&bt, "%H:%M:%S"); // HH:MM:SS
  oss << '.' << std::setfill('0') << std::setw(3) << ms.count();

  return oss.str();
}
int64_t time_in_HH_MM_SS_MMM1()
{
  using namespace std::chrono;

  // get current time
  auto now = system_clock::now();

  // get number of milliseconds for the current second
  // (remainder after division into seconds)
  auto ms = duration_cast<milliseconds>(now.time_since_epoch()) % 1000;
  auto us = duration_cast<microseconds>(now.time_since_epoch()) % 1000;

  // convert to std::time_t in order to convert to std::tm (broken time)
  auto timer = system_clock::to_time_t(now);

  // convert to broken time
  std::tm bt = *std::localtime(&timer);

  std::ostringstream oss;

  oss << std::put_time(&bt, "%H:%M:%S"); // HH:MM:SS
  oss << '.' << std::setfill('0') << std::setw(3) << ms.count();
  // oss << '.' << std::setfill('0') << std::setw(3) << us.count();
  // int64_t microesec = static_cast<int64_t>(us / microseconds(1));
  int64_t sec = static_cast<int64_t>(now.time_since_epoch() / nanoseconds(1));

  // return oss.str();
  return sec;
}

FILE *pFILE2;

void rf_ecpri_suppress_stdout(void *h)
{
  ecpri_args = (ecpri_args_t *)malloc(sizeof(ecpri_args_t));
  bzero(ecpri_args, sizeof(ecpri_args_t));
  ecpri_args = (ecpri_args_t *)h;
}

void rf_ecpri_register_error_handler(void *notused, srslte_rf_error_handler_t new_handler)
{
  printf(" rf_ecpri_register_error_handler \n");
}

bool rf_ecpri_rx_wait_lo_locked(void *h) {}

char *rf_ecpri_devname(void *h)
{

  return "ECPRI";
}

int rf_ecpri_start_rx_stream(void *h, bool now)
{
  return 0;
}

int rf_ecpri_stop_rx_stream(void *h)
{
  return 0;
}

void rf_ecpri_flush_buffer(void *h) {}

bool rf_ecpri_has_rssi(void *h)
{
  return 0;
}

float rf_ecpri_get_rssi(void *h)
{
  return 0;
}

int rf_ecpri_close(void *h)
{
  return SRSLTE_SUCCESS;
}

int rf_ecpri_open_multi(char *args, void **h, uint32_t nof_channels)
{
  for (int p = 0; p < 10; p++)
    {
        r_buffer[p][0] = (uint8_t *)malloc(11520*8);
        r_buffer[p][1] = (uint8_t *)malloc(11520*8);
    }
  ecpri_args_t *handler = (ecpri_args_t *)malloc(sizeof(ecpri_args_t));
  if (!handler)
  {
    perror("malloc");
    return -1;
  }
  bzero(handler, sizeof(ecpri_args_t));
  *h = handler;
  txrx_class *txrx_class = txrx_class::get_instance();
  txrx_class->txrx_init(5059, 8820, ecpri_args->bbu_addr.c_str(), ecpri_args->rru_addr.c_str());
  pFILE2 = fopen("time.bin", "wb");
  params.rx_channel_count = nof_channels;
  params.tx_channel_count = nof_channels;
  return 0;
}

int rf_ecpri_open(char *args, void **h)
{
  return 0;
}

void rf_ecpri_set_master_clock_rate(void *h, double rate)
{
  printf("rf_ecpri_master_clock_rate \n");
}

bool rf_ecpri_is_master_clock_dynamic(void *h)
{
  return 0;
}

double rf_ecpri_set_rx_srate(void *h, double rate)
{
  params.rx_rate = rate;
  return 0;
}

double rf_ecpri_set_tx_srate(void *h, double rate)
{
  params.tx_rate = rate;
  return rate;
}

double rf_ecpri_set_rx_gain(void *h, double gain)
{
  if (gain > 0)
    params.rx_gain = gain;
  if (gain)
    return SRSLTE_SUCCESS;
  else
    return SRSLTE_ERROR;
  // return gain;
}

int rf_ecpri_set_rx_gain_ch(void *h, uint32_t ch, double gain)
{
  return SRSLTE_SUCCESS;
}

double rf_ecpri_set_tx_gain(void *h, double gain)
{
  params.tx_gain = gain;
  if (gain)
    return SRSLTE_SUCCESS;
  else
    return SRSLTE_ERROR;
}

int rf_ecpri_set_tx_gain_ch(void *h, uint32_t ch, double gain)
{
  return SRSLTE_SUCCESS;
}

double rf_ecpri_get_rx_gain(void *h)
{
  return 0;
}

double rf_ecpri_get_tx_gain(void *h)
{
  return 0;
}

srslte_rf_info_t *rf_ecpri_get_info(void *h)
{
  x.max_rx_gain = 0;
  x.max_tx_gain = 0;
  x.min_rx_gain = 0;
  x.min_tx_gain = 0;
  return &x;
}

double rf_ecpri_set_rx_freq(void *h, uint32_t ch, double freq)
{
  params.rx_freq = freq;
  return freq;
}

double rf_ecpri_set_tx_freq(void *h, uint32_t ch, double freq)
{

  params.tx_freq = freq;
  return freq;
}

void rf_ecpri_get_time(void *h, time_t *secs, double *frac_secs) {}
int rf_ecpri_recv_with_time_multi(void *h,
                                  void **data,
                                  uint32_t nsamples,
                                  bool blocking,
                                  time_t *secs,
                                  double *frac_secs)
{

  params.port_count = 1;

  int ret = 0;
  int nof_bytes_BW = nsamples * 8;

  txrx_class *txrx_class = txrx_class::get_instance();

  uint16_t RTC_seqID = 0;
  uint16_t *reset_ID = (uint16_t *)malloc(sizeof(uint16_t));
  uint16_t TXreset_ID = 0;
  uint16_t RXreset_ID = 0;

  int64_t rx_timestamp = 0;
  int rx_len = 0;
  uint8_t *data_8 = (uint8_t *)malloc(nof_bytes_BW);
  int nof_bytes = (params.tx_rate / 1000) * 8;

  cf_t *data_c;
  uint32_t rx_packet = 0;
  int64_t bb = time_in_HH_MM_SS_MMM1();
  while (rx_packet < (nsamples * 8))
  {
    if (BBU_start)
    {
      printf("BBU started\n");
      BBU_start = 0;
      txrx_class->Remote_Reset_send_req(TXreset_ID, ECPRI_RMR_REQ);
    }

    if (txrx_class->Remote_Reset_recv_req(&RXreset_ID, &rx_timestamp)) // if reset request received then send reset response to rru
    {
      printf("RRU start...\n");
      txrx_class->Remote_Reset_send_resp(RXreset_ID, ECPRI_RMR_RESP);
      printf("TXrate = %d, RXrate = %d , TXgain = %f, RXgain = %f, TXfreq= %ld, RXfreq = %ld \n",
             params.tx_rate, params.rx_rate, params.tx_gain, params.rx_gain, params.tx_freq, params.rx_freq);
      txrx_class->RTC_send_req(params, RTC_req, RTC_seqID);
      RTC_seqID += 1;

      while (!txrx_class->RTC_recv_resp())
      {
        usleep(20);
      }
      BBU_start = 0;
    }

    usleep(20);

    if (txrx_class->recv_data(data_8, &rx_len, &rx_timestamp, nof_bytes))
    {

      for (int i = 0; i < 1; i++)
      {
        data_c = (cf_t *)data[i];
      }
      // if (co <5)
      // {
      //         continue;
      // }

      memcpy(data_c + rx_packet, data_8, (rx_len) * sizeof(uint8_t));
      rx_packet = rx_packet + rx_len;
      flag_not = false;
    }
    else
    {
      int64_t aa = time_in_HH_MM_SS_MMM1();
      if (((aa - bb) / 1000) > 2000)
      {
        rx_packet = nsamples * 8;
        rx_timestamp = tmp_time + nsamples;
        //  printf("Drop rx data ,  rx_timestamp = %ld delay = %ld\n", rx_timestamp, ((aa - bb) / 1000));
        flag_not = true;
      }
    }
    if (rx_timestamp <= tmp_time && tmp_time - rx_timestamp < 300 * nsamples)
    {
      co ++;
      rx_packet = 0;      
      continue;
    }
  }
  co = 0;
  ret = nof_bytes;
  tmp_time = rx_timestamp;
  *secs = rx_timestamp / (nsamples * 1000);
  *frac_secs = ((double)((rx_timestamp) % (nsamples * 1000))) / ((double)(nsamples * 1000));
  // printf("rxxxxxxxxxx_timestamp %s %ld %ld %f\n",time_in_HH_MM_SS_MMM222().c_str(),rx_timestamp , *secs ,*frac_secs);

  free(data_8);

  return ret;
}

int rf_ecpri_recv_with_time(void *h, void *data, uint32_t nsamples, bool blocking, time_t *secs, double *frac_secs)
{
  return 0;
  // printf("The Recv Function 2\n");
}

void rf_ecpri_sync_pps(void *h) {}

int rf_ecpri_send_timed_multi(void *h,
                              void *data[4],
                              int nsamples, // 5760
                              time_t secs,  //
                              double frac_secs,
                              bool has_time_spec,
                              bool blocking,
                              bool is_start_of_burst,
                              bool is_end_of_burst)
{
  uint8_t *uu[2] = {};

  uu[0] = (uint8_t *)data[0];
  uu[1] = (uint8_t *)data[1];
  txrx_class *txrx_class = txrx_class::get_instance();
  int nof_bytes = (params.tx_rate / 1000) * 8;
  int tx_packet = 0;

  int64_t tx_timestamp = (secs + frac_secs) * nsamples * 1000;

  if ( tx_timestamp-tmp1 >nsamples)
  {
    printf("\n cur_time: %s tx_timestamp: %ld tmp_timestamp: %ld\n",time_in_HH_MM_SS_MMM222().c_str(),tx_timestamp , tmp1);
    int64_t last_time = tmp1;
    
  }
  while ((tx_timestamp - tmp1 - nsamples) < 0)
  {

    tx_timestamp++;
  }
  tmp1 = tx_timestamp;

  tmp_time2 = tx_timestamp;


    txrx_class->send_data(uu, nof_bytes, tx_timestamp, 50);
  // memcpy(r_buffer[count_tti][0],uu[0],nsamples*8);
  // memcpy(r_buffer[count_tti][1],uu[1],nsamples*8);
  // count_tti ++;
  // if (count_tti >9)
  // {
  //   count_tti = 0;
  // }
  
  return tx_packet;
}

int rf_ecpri_send_timed(void *h,
                        void *data,
                        int nsamples,
                        time_t secs,
                        double frac_secs,
                        bool has_time_spec,
                        bool blocking,
                        bool is_start_of_burst,
                        bool is_end_of_burst)
{
  return 0;
}
