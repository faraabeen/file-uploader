/**
 * Copyright 2013-2021 Software Radio Systems Limited
 *
 * This file is part of srsRAN.
 *
 * srsRAN is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * srsRAN is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * A copy of the GNU Affero General Public License can be found in
 * the LICENSE file in the top-level directory of this distribution
 * and at http://www.gnu.org/licenses/.
 *
 */

#include "srslte/asn1/rrc_utils.h"
// #include "srslte/asn1/rrc.h"
#include "srslte/config.h"
#include <algorithm>
#include <srslte/common/interfaces_common.h>

namespace srsenb {

using namespace asn1::rrc;

/*
 * UE Capabilities parser
 */

// template <class T>
// static void set_rrc_ue_eutra_cap_t_gen(phy_interface_rrc::rrc_ue_capabilities_t& ue_cap, const T& ue_eutra_cap)
// {
//   if (ue_eutra_cap.non_crit_ext_present) {
//     set_rrc_ue_eutra_cap_t_gen(ue_cap, ue_eutra_cap.non_crit_ext);
//   }
// }

void set_rrc_ue_eutra_cap_t_gen(phy_interface_rrc::rrc_ue_capabilities_t& ue_cap,
                                const asn1::rrc::ue_eutra_cap_s&          ue_eutra_cap)
{
  ue_cap.release  = ue_eutra_cap.access_stratum_release.to_number();
  ue_cap.category = ue_eutra_cap.ue_category;

  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_920(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1250(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1250_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.ue_category_dl_r12_present) {
    ue_cap.category_dl = ue_eutra_cap.ue_category_dl_r12;
  }

  if (ue_eutra_cap.ue_category_ul_r12_present) {
    ue_cap.category_ul = ue_eutra_cap.ue_category_ul_r12;
  }

  if (ue_eutra_cap.rf_params_v1250_present) {
    const asn1::rrc::rf_params_v1250_s& rf_params = ue_eutra_cap.rf_params_v1250;
    if (rf_params.supported_band_list_eutra_v1250_present) {
      ue_cap.support_dl_256qam = true;
      ue_cap.support_ul_64qam |= (ue_cap.category_ul == 5 or ue_cap.category_ul == 13) and ue_cap.release >= 10;
      // for (const asn1::rrc::supported_band_eutra_v1250_s& supported_band : rf_params.supported_band_list_eutra_v1250)
      // {
      for (uint32_t i1 = 0; i1 < rf_params.supported_band_list_eutra_v1250.size(); ++i1) {
        ue_cap.support_dl_256qam &= rf_params.supported_band_list_eutra_v1250[i1].dl_minus256_qam_r12_present;
        ue_cap.support_ul_64qam  &= rf_params.supported_band_list_eutra_v1250[i1].ul_minus64_qam_r12_present;
          // printf("\n 64QAM[3]: %d",ue_cap.support_ul_64qam);

      }
    }
  }

  // if (ue_eutra_cap.non_crit_ext_present) {
  //   set_rrc_ue_eutra_cap_t_gen(ue_cap, ue_eutra_cap.non_crit_ext);
  // }
}

void set_rrc_ue_eutra_cap_t_gen_11a0(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v11a0_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_1250(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1180(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1180_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_11a0(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1170(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1170_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_1180(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1130(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1130_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_1170(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1090(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1090_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_1130(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1060(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1060_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_1090(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1020(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1020_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.ue_category_v1020_present) {
    ue_cap.category = ue_eutra_cap.ue_category_v1020;
  }

  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_1060(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_940(phy_interface_rrc::rrc_ue_capabilities_t& ue_cap,
                                    const asn1::rrc::ue_eutra_cap_v940_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_1020(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_920(phy_interface_rrc::rrc_ue_capabilities_t& ue_cap,
                                    const asn1::rrc::ue_eutra_cap_v920_ies_s& ue_eutra_cap)
{
  if (ue_eutra_cap.non_crit_ext_present) {
    set_rrc_ue_eutra_cap_t_gen_940(ue_cap, ue_eutra_cap.non_crit_ext);
  }
}

void set_rrc_ue_eutra_cap_t_gen_1530(phy_interface_rrc::rrc_ue_capabilities_t&  ue_cap,
                                     const asn1::rrc::ue_eutra_cap_v1530_ies_s& ue_eutra_cap)
{
  ; // Do nothing
}

phy_interface_rrc::rrc_ue_capabilities_t make_rrc_ue_capabilities(const asn1::rrc::ue_eutra_cap_s& eutra_cap_s)
{
  phy_interface_rrc::rrc_ue_capabilities_t ue_cap;
  set_rrc_ue_eutra_cap_t_gen(ue_cap, eutra_cap_s);
  // printf("\n 64QAM[1]: %d",ue_cap.support_ul_64qam);
  ue_cap.support_ul_64qam |= (ue_cap.category == 5) or (ue_cap.category == 8 and ue_cap.release >= 10);
  printf("\n 64QAM: %d",ue_cap.support_ul_64qam);

  return ue_cap;
}


void set_phy_cfg_t_enable_64qam(bool enabled)
{
  // cfg->ul_cfg.pusch.enable_64qam = enabled;
}


} // namespace srsenb
